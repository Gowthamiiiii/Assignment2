import cv2 as cv
# img = cv.imread('image.jpg')
# cv.imshow('Gowthami Duggineni',img)
# cv.waitKey(0)

# reading video

capture = cv.VideoCapture('dance.gif')

while True:
    isTrue, frame = capture.read()
    cv.imshow('winname', frame)
    
    if cv.waitKey(20) & 0:
        break
    
capture.release()
cv.destroyAllWindows()